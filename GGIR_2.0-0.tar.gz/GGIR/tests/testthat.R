library("testthat")
library("GGIR")
test_check("GGIR")